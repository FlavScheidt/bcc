/************************
	Biblioteca para relacionada a tudo que é mostrado na tela
	(impressão e consulta)
************************/
void ImprimeMeni();
void ImprimeAluno(aluno *);
void ImprimeNotas(matricula *);
int ConsultaAluno(int, aluno *, matricula *);
int ConsultaDisciplina(char *, aluno *, matricula *);
