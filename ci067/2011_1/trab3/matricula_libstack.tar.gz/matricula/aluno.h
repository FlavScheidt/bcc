aluno * InsereAluno(int, char *, aluno *);
aluno * RemoveAluno(int, aluno *);
aluno * DestroiAlunos(aluno *);
aluno * ProcuraAlunos(aluno *, int);
