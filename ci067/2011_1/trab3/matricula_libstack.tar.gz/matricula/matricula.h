matricula * InsereMatricula(char *, int, matricula *);
matricula * RemoveMatricula(char *, int, matricula *);
matricula * DestroiMatricula(matricula *);
matricula * ProcuraMatricula(matricula *, int, char *);
int EstaMatriculado(int, matricula *);
int AlteraNotas(matricula *, int, char *, int, int);
