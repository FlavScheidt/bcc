#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/************************
	Estruturas
************************/
typedef struct estruturaAeroporto;
typedef struct estruturaVoo //Estrutura de cada voo (lista encadeada)
{
	estruturaAeroporto *destino;
	int numvoo;
	estruturaVoo *prox;
} estruturaVoo;
struct estruturaAeroporto //Estrutura de cada aeroporto (vetor)
{
	int ID;
	char *cidade;
	char *codigo;
	int voos;
	estruturaVoo *adjacencia;
}
/************************
	Funções
************************/
estruturaAeroporto* IniciaLista (estruturaAeroporto *Lista) //Inicia o vetor de aeroportos
{
	int i;	
	for (i=0; i<=10; i++)
	{
		Lista[i].ID = i; //Atribui uma ID
		Lista[i].cidade = "<vazio>";
		Lista[i].codigo = "<vazio>";
		Lista[i].voos = 0;
		Lista[i].adjacencia = (estruturaVoo*) malloc (sizeof(estruturaVoo)); //Aloca lista de adjacencias
		Lista[i].adjacencia -> *prox = NULL;
	}
	return(Lista);
}
estruturaAeroporto* CadastraAeroporto (estruturaAeroporto *Lista, char *cidade, char *codigo)
{
	int ID;
	int i = 0;
	while ((i <= 10) || (Lista[i].cidade == "<vazio>")) //Percorre vetor buscando posição vazia
	{
		i++;
	}
	if (Lista[i].cidade == "<vazio>") //Se chegou ao fim do vetor, verifica se a última posição é vazia
	{
		Lista[i].cidade = cidade;
		Lista[i].codigo = codigo;
		printf("\nAeroporto inserido com a ID %d\n", Lista[i].ID)
		return(Lista);
	}
	else
	{
		printf("\nImpossível Cadastrar. Número máximo de aeroportos excedido\n");
		return(Lista);
	}
}
estruturaAeroporto* CadastraVoo(int numvoo; char *origem; char *destino; estruturaAeroporto *Lista)
{
	int encontrou = 0;
	int i = 0;
	int j = 0;
	/***** Busca origem *****/
	while ((i <= 9) || (encontrou = 0))
	{
		if (Lista[i].codigo == origem)
		{
			encontrou = 1;
		}
		else
		{
			i++;
		}
	}
	encontrou = 0;
	/***** Busca destino *****/
	while ((j <= 9) || (encontrou = 0))
	{
		if (Lista[j].codigo == destino)
		{
			encontrou = 1;
		}
		else
		{
			j++;
		}
	}
	estruturaVoo *novo = (estruturaVoo*) malloc (sizeof(estruturaVoo));
	Lista[i].adjacencia -> numvoo;
	Lista[i].adjacencia -> Lista[j];
	novo -> prox = Lista[i].adjacencia;
	Lista[i].adjacencia = novo;
	Lista[i].voos++;
	return(Lista[i]);
}
estruturaAeroporto* RemoveVoo (int numvoo; estruturaAeroporto *Lista)
{
	int encontrou = 0;
	int i = 0;
	int j = 0;
	estruturaVoo *nodo = Lista[i].adjacencia;
	estruturaVoo *anterior = nodo;
	while ((encontrou = 0) || (i <= 9))
	{
		while ((j <= Lista[i]. voos) || (encontrou == 0))
		{
			if (nodo -> numvoo  == numvoo)
			{
				encontrou = 1;
			}
			else
			{
				anterior = nodo;
				nodo = nodo -> prox;
				j++;
			}
			i++;
		}
		if (encontrou == 0)
		{
			printf("\nVoo não encontrado");
			return(Lista);
		}
		else
		{
			anterior -> prox = nodo -> prox;
			free(nodo);
			return(Lista);
		}
	}
}
void ImprimeVoos (char *codigo, estruturaAeroporto *Lista)
{
	int encontrou = 0;
	int i = 0;
	estruturaVoo *aux;
	while ((i <= 9) || (encontrou == 0))
	{
		if (Lista[i].codigo == codigo)
		{
			encontrou = 1;
		}
		else
		{
			i++;
		}
	}
	for (aux = Lista[i].adjacencia; aux != NULL; aux = aux ->prox)
	{
		printf("-----------------------------");
		printf("%d - %s", Lista[i].codigo, aux -> numvoo);
	}
}
void ImprimeTudo (estruturaAeroporto *Lista)
{
	int i;
	for (i = 0; i <= 9; i++)
	{
		printf("------------------");
		printf("------------------");
		printf("Destino: %s", Lista[i].cidade);
		printf("------------------");
		printf("------------------");
		estruturaVoo *aux;
		for (aux = Lista[i].adjacencia; aux != NULL; aux = aux -> prox)
		{
			printf("----------");
			printf("%d - %s", Lista[i].codigo; aux -> numvoo);
		}
	}
}
/***********************
	Programa Principal
************************/
main ()
{
	char cidade[30];
	char codigo[4];
	char opcao;
	char numvoo[4];
	char codigodestino[4];
	/***** Vetor *****/
	estruturaAeroporto Lista[10];
	IniciaVetor(Lista);
	/***** Menu *****/
	while (opcao != "Q")
	{
		printf("----------------------\n");
		printf("A - Inserir Aeroporto\n");
		printf("B - Inserir Voo\n");
		printf("C - Remover Voo\n");
		printf("D - Buscar Voo\n");
		printf("E - Imprimir voos partindo de um aeroporto\n");
		printf("F - Imprimir tudo\n");
		printf("Q - Sair\n");
		printf("----------------------\n");
		getchar(opcao);
		strupr(opcao);
		getchar();
		switch (opcao)
		{
			case 'A'
			{
				/***** Cadastra aeroporto *****/
				printf("\nInsira o nome da cidade");
				fgets(cidade, 30*sizeof(char), stdin);
				printf("\nInsira o código do aeroporto");
				fgets(codigo, 4*sizeof(char), stdin);
				CadastraAeroporto(Lista, cidade, codigo);
				break;
			}
			case 'B'
			{
				printf("\nNúmero de voo");
				fgets(numvoo, 4*sizeof(char), stdin);
				printf("\nAeroporto de origem");
				fgets(codigo, 4*sizeof(char), stdin);
				printf("\nAeroporto de destino");
				fgets(codigodestino, 4*sizeof(char), stdin);
				CadastraVoo(numvoo, codigo, codigodestino, Lista);
				printf("Vôo cadastrado com sucesso");
				break;
			}
			case 'C'
			{
				printf("\nInforme o número do Vôo");
				fgets(numvoo, 4*sizeof(char), stdin);
				RemoveVoo(numvoo, Lista);
				break;
			}
			case 'D'
			{	
				printf("Função não implementada");
				break;
			}
			case 'E'
			{
				printf("\nInsira o código do aeroporto");
				fgets(codigo, 4*sizeof(char), stdin);
				ImprimeVoos(codigo, Lista);
				break;
			}
			case 'F'
			{
				ImprimeTudo(Lista);
				break;
			}
	}
}
